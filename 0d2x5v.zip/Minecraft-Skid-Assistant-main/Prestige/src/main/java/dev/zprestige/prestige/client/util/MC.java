package dev.zprestige.prestige.client.util;

import net.minecraft.client.MinecraftClient;

public interface MC {
    MinecraftClient getMc();
}
