package dev.zprestige.prestige.client.event;

public enum Phase {
    PRE,
    POST,
    NONE;
}
