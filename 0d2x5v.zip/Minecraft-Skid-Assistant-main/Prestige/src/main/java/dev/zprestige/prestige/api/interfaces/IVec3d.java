package dev.zprestige.prestige.api.interfaces;

public interface IVec3d {
    void set(double var1, double var3, double var5);
}
