package dev.zprestige.prestige.client.protection.check;

public enum Category {
    Normal,
    Session,
}
