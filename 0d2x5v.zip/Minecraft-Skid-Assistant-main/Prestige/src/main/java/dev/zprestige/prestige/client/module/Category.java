package dev.zprestige.prestige.client.module;

public enum Category {
    Combat,
    Misc,
    Movement,
    Visual,
    Menu,
    Configs
}
