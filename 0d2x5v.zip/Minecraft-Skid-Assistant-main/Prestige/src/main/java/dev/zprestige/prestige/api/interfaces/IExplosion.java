package dev.zprestige.prestige.api.interfaces;

import net.minecraft.util.math.Vec3d;

public interface IExplosion {
    void set(Vec3d var1, float var2, boolean var3);
}
