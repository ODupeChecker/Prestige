package dev.zprestige.prestige.client.ui.drawables.gui.screens;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class DrawableScreen extends Screen {

    public DrawableScreen() {
        super(Text.of(""));
    }
}
