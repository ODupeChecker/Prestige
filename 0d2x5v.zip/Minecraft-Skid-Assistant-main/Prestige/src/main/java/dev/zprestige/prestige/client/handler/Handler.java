package dev.zprestige.prestige.client.handler;

public interface Handler {
    public void register();
}
