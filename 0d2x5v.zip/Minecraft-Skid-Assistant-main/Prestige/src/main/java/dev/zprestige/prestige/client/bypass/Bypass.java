package dev.zprestige.prestige.client.bypass;

public class Bypass {
    public String field1707;

    public String method1730() {
        return this.field1707;
    }

    public Bypass(String string) {
        this.field1707 = string;
    }

    public String run() {
        return "";
    }
}
