package dev.zprestige.prestige.api.interfaces;

import dev.zprestige.prestige.client.util.impl.Rotation;

public interface IRotatable {
    public Rotation getRotation();
}
